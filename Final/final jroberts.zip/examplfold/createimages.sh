#!/bin/bash

i=0
for i in 1 2 3 4 5; do
    touch "ex$i.jpg"
    touch "ex$i.jpeg"
    touch "ex$i.png"
    touch "ex$i.tiff"
    touch "ex$i.webp"
done